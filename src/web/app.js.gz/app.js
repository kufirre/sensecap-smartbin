// (() => {
//   // Point at your local helper while testing on PC.
//   // When you move to the ESP, set API_BASE = "" (same-origin).
//  //  const API_BASE = "http://localhost:3000";
//   const API_BASE = "" 

//   // Single source of truth for fetch
//   async function fetchJSON(url, opts) {
//     const full = (API_BASE || "") + url;
//     console.log("fetch:", full, opts || {});
//     const res = await fetch(full, opts);
//     console.log("status:", res.status);
//     if (!res.ok) {
//       const txt = await res.text().catch(() => "");
//       throw new Error(`HTTP ${res.status} ${txt}`);
//     }
//     return res.json();
//   }

//   let availableNetworks = [];
//   let currentConfig = {}; // Store loaded config

//   const $ = (sel) => document.querySelector(sel);
//   const $$ = (sel) => document.querySelectorAll(sel);

//   function setStatus(kind, text) {
//     const box = document.createElement("div");
//     box.className = `status ${kind}`;
//     box.textContent = text;
//     const holder = $("#status");
//     holder.innerHTML = "";
//     holder.appendChild(box);
//   }

//   function clearStatus() {
//     $("#status").innerHTML = "";
//   }

//   function isOpen(authmode) {
//     // Accept common representations from various scan APIs
//     return authmode === 0 || authmode === "OPEN" || authmode === "WIFI_AUTH_OPEN";
//   }

//   // Password toggle functionality with modern eye icons
//   function togglePasswordVisibility(button) {
//     const targetId = button.getAttribute("data-target");
//     const input = $("#" + targetId);
//     const svg = button.querySelector("svg path");
    
//     if (input.type === "password") {
//       input.type = "text";
//       // Standard eye-off icon (hidden)
//       svg.setAttribute("d", "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z M9.9 9.9c-.7.7-1.1 1.7-1.1 2.7s.4 2 1.1 2.7l4.2-4.2c-1.5-.5-3.2-.1-4.2.8z M14.1 14.1c.7-.7 1.1-1.7 1.1-2.7s-.4-2-1.1-2.7l-4.2 4.2c1.5.5 3.2.1 4.2-.8z M1 1l22 22");
//       button.setAttribute("title", "Hide password");
//     } else {
//       input.type = "password";
//       // Normal eye
//       svg.setAttribute("d", "M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z");
//       button.setAttribute("title", "Show password");
//     }
//   }

//   async function loadConfig() {
//     try {
//       const data = await fetchJSON("/api/config");
//       currentConfig = data; // Store current config
      
//       if (data.wifi_ssid) {
//         $("#wifi_ssid").value = data.wifi_ssid;
//         $("#wifi-status").textContent = `Connected: ${data.wifi_ssid}`;
//       }
//       if (data.post_code) $("#post_code").value = data.post_code;
//       if (data.bin_color) $("#bin_color").value = data.bin_color;
      
//       // Update status message if connected
//       if (data.wifi_ssid) {
//         setStatus("success", "✅ WiFi Connected - Configuration portal remains accessible");
//       }
//     } catch (_) {
//       // No existing configuration; ignore
//     }
//   }

//   function displayNetworks() {
//     const container = $("#networks");
//     container.innerHTML = "";

//     if (!Array.isArray(availableNetworks) || availableNetworks.length === 0) {
//       const row = document.createElement("div");
//       row.className = "network-item";
//       row.textContent = "No networks found";
//       container.appendChild(row);
//     } else {
//       availableNetworks.forEach((net) => {
//         const ssid = typeof net.ssid === "string" ? net.ssid : "";
//         const rssi = typeof net.rssi === "number" ? net.rssi : "";
//         const auth = net.authmode;

//         const row = document.createElement("div");
//         row.className = "network-item";

//         const name = document.createElement("span");
//         name.textContent = ssid || "(hidden SSID)";

//         const strength = document.createElement("span");
//         strength.className = "signal-strength";
//         strength.textContent = `${rssi}dBm ${isOpen(auth) ? "[OPEN]" : "[SECURED]"}`;

//         row.appendChild(name);
//         row.appendChild(strength);
//         row.addEventListener("click", () => {
//           $("#wifi_ssid").value = ssid;
//           container.style.display = "none";
//         });

//         container.appendChild(row);
//       });
//     }

//     container.style.display = "block";
//   }

//   async function scanNetworks() {
//     setStatus("info", "🔎 Scanning for WiFi networks...");
//     try {
//       const data = await fetchJSON("/api/scan");
//       console.log("scan data:", data);
//       availableNetworks = Array.isArray(data.networks) ? data.networks : [];
//       displayNetworks();
//       clearStatus();
//     } catch (err) {
//       console.error("scan error:", err);
//       setStatus("error", `❌ Failed to scan networks (${String(err).slice(0, 120)})`);
//     }
//   }

//   async function submitConfig(e) {
//     e.preventDefault();

//     // Build config with only non-empty values, preserving existing values for empty fields
//     const config = {};
    
//     const wifi_ssid = $("#wifi_ssid").value.trim();
//     const wifi_password = $("#wifi_password").value;
//     const openai_api_key = $("#openai_api_key").value;
//     const post_code = $("#post_code").value.trim();
//     const bin_color = $("#bin_color").value;

//     // Only include non-empty values, or preserve existing if field is empty
//     if (wifi_ssid) config.wifi_ssid = wifi_ssid;
//     else if (currentConfig.wifi_ssid) config.wifi_ssid = currentConfig.wifi_ssid;

//     if (wifi_password) config.wifi_password = wifi_password;
//     else if (currentConfig.wifi_password) config.wifi_password = currentConfig.wifi_password;

//     if (openai_api_key) config.openai_api_key = openai_api_key;
//     else if (currentConfig.openai_api_key) config.openai_api_key = currentConfig.openai_api_key;

//     if (post_code) config.post_code = post_code;
//     else if (currentConfig.post_code) config.post_code = currentConfig.post_code;

//     if (bin_color && bin_color !== "none") config.bin_color = bin_color;
//     else if (currentConfig.bin_color) config.bin_color = currentConfig.bin_color;

//     if (!config.wifi_ssid) {
//       setStatus("error", "❌ Please enter WiFi network name");
//       return;
//     }

//     setStatus("info", "💾 Saving configuration...");

//     try {
//       const data = await fetchJSON("/api/config", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(config)
//       });

//       if (data && data.status === "success") {
//         setStatus("success", "✅ Configuration saved! Device will connect to WiFi. This portal remains accessible.");
//         // Update stored config
//         currentConfig = {...currentConfig, ...config};
//       } else {
//         const msg = (data && data.message) ? String(data.message) : "Unknown error";
//         setStatus("error", `❌ ${msg}`);
//       }
//     } catch (err) {
//       console.error("config post error:", err);
//       setStatus("error", `❌ Network error. Please try again. (${String(err).slice(0, 120)})`);
//     }
//   }

//   function wirePressFeedback(btn) {
//     btn.addEventListener("pointerdown", () => btn.classList.add("is-pressed"));
//     window.addEventListener("pointerup", () => btn.classList.remove("is-pressed"));
//     btn.addEventListener("keydown", (e) => {
//       if (e.key === " " || e.key === "Enter") btn.classList.add("is-pressed");
//     });
//     btn.addEventListener("keyup", () => btn.classList.remove("is-pressed"));
//   }

//   function init() {
//     const scanBtn = $("#scan-btn");
//     wirePressFeedback(scanBtn);

//     // Wire up password toggle buttons
//     $$(".toggle-password").forEach(button => {
//       button.setAttribute("title", "Show password");
//       button.addEventListener("click", () => togglePasswordVisibility(button));
//     });

//     scanBtn.addEventListener("click", scanNetworks);
//     $("#configForm").addEventListener("submit", submitConfig);

//     loadConfig();
//     // Auto-scan once after load
//     setTimeout(scanNetworks, 1000);
//   }

//   document.addEventListener("DOMContentLoaded", init);
// })();

// SmartBin Configuration Interface
class SmartBinConfig {
  constructor() {
    this.currentTheme = localStorage.getItem('theme') || 'light';
    this.networks = [];
    this.currentConfig = {};
    this.isScanning = false;

    this.initializeTheme();
    this.initializeEventListeners();
    this.loadCurrentConfig();
    this.scanWifiNetworks();
  }

  // Theme Management
  initializeTheme() {
    document.documentElement.setAttribute('data-theme', this.currentTheme);
    const themeToggle = document.getElementById('themeToggle');
    themeToggle.addEventListener('click', () => this.toggleTheme());
  }

  toggleTheme() {
    this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', this.currentTheme);
    localStorage.setItem('theme', this.currentTheme);
  }

  // Event Listeners
  initializeEventListeners() {
    // WiFi refresh button
    const refreshBtn = document.getElementById('refreshWifi');
    refreshBtn.addEventListener('click', () => this.scanWifiNetworks());

    // Configuration form
    const configForm = document.getElementById('configForm');
    configForm.addEventListener('submit', (e) => this.handleConfigSubmit(e));

    // Password toggles
    const toggleButtons = document.querySelectorAll('.toggle-password');
    toggleButtons.forEach((button) => {
      button.addEventListener('click', () => this.togglePasswordVisibility(button));
    });

    // Modal listeners
    const modalClose = document.getElementById('modalClose');
    const modalOverlay = document.getElementById('wifiModal');
    const cancelConnect = document.getElementById('cancelConnect');
    const wifiForm = document.getElementById('wifiForm');

    modalClose.addEventListener('click', () => this.closeWifiModal());
    cancelConnect.addEventListener('click', () => this.closeWifiModal());
    modalOverlay.addEventListener('click', (e) => { if (e.target === modalOverlay) this.closeWifiModal(); });
    wifiForm.addEventListener('submit', (e) => this.handleWifiConnect(e));
  }

  // Password Visibility Toggle
  togglePasswordVisibility(button) {
    const targetId = button.getAttribute('data-target');
    const input = document.getElementById(targetId);
    const eyeOpen = button.querySelector('.eye-open');
    const eyeClosed = button.querySelector('.eye-closed');

    if (input.type === 'password') {
      input.type = 'text';
      eyeOpen.style.display = 'none';
      eyeClosed.style.display = 'block';
    } else {
      input.type = 'password';
      eyeOpen.style.display = 'block';
      eyeClosed.style.display = 'none';
    }
  }

  // Load Current Configuration
  async loadCurrentConfig() {
    try {
      const response = await fetch('/api/config');
      if (response.ok) {
        this.currentConfig = await response.json();
        this.populateConfigForm();
      }
    } catch (error) {
      console.error('Failed to load configuration:', error);
      this.showToast('Failed to load configuration', 'error');
    }
  }

  // Populate Configuration Form
  populateConfigForm() {
    const postCodeInput = document.getElementById('postCode');
    if (this.currentConfig.post_code) {
      postCodeInput.value = this.currentConfig.post_code;
    }

    // Set bin color
    if (this.currentConfig.bin_color) {
      const colorInput = document.querySelector(`input[name="bin_color"][value="${this.currentConfig.bin_color}"]`);
      if (colorInput) colorInput.checked = true;
    }
  }

  // WiFi Network Scanning
  async scanWifiNetworks() {
    if (this.isScanning) return;

    this.isScanning = true;
    const refreshBtn = document.getElementById('refreshWifi');
    const loadingSpinner = document.getElementById('wifiLoading');
    const networksList = document.getElementById('networksList');

    refreshBtn.classList.add('spinning');
    loadingSpinner.style.display = 'flex';
    networksList.innerHTML = '';

    try {
      const response = await fetch('/api/scan');
      if (response.ok) {
        const data = await response.json();
        this.networks = (data.networks || []).filter(n => !!n.ssid);
        this.renderNetworks();
      } else {
        throw new Error('Failed to scan networks');
      }
    } catch (error) {
      console.error('WiFi scan failed:', error);
      this.showToast('WiFi scan failed', 'error');
    } finally {
      this.isScanning = false;
      refreshBtn.classList.remove('spinning');
      loadingSpinner.style.display = 'none';
    }
  }

  // Render Network List
  renderNetworks() {
    const networksList = document.getElementById('networksList');
    networksList.innerHTML = '';

    if (this.networks.length === 0) {
      networksList.innerHTML = '<div class="no-networks">No networks found</div>';
      return;
    }

    // Sort: connected network first, then by RSSI
    const sortedNetworks = [...this.networks].sort((a, b) => {
      const aIsConnected = a.ssid === this.currentConfig.wifi_ssid;
      const bIsConnected = b.ssid === this.currentConfig.wifi_ssid;
      if (aIsConnected && !bIsConnected) return -1;
      if (!aIsConnected && bIsConnected) return 1;
      return (b.rssi || -999) - (a.rssi || -999);
    });

    sortedNetworks.forEach((network) => {
      const networkElement = this.createNetworkElement(network);
      networksList.appendChild(networkElement);
    });
  }

  // Create Network Element
  createNetworkElement(network) {
    const networkItem = document.createElement('div');
    const isCurrentNetwork = network.ssid === this.currentConfig.wifi_ssid;

    networkItem.className = isCurrentNetwork ? 'network-item connected-network' : 'network-item';
    networkItem.addEventListener('click', () => this.openWifiModal(network));

    const networkInfo = document.createElement('div');
    networkInfo.className = 'network-info';

    const networkName = document.createElement('div');
    networkName.className = 'network-name';
    networkName.textContent = network.ssid;

    const networkSecurity = document.createElement('div');
    networkSecurity.className = 'network-security';

    const securityIcon = this.createSecurityIcon(network.authmode);
    const securityText = document.createElement('span');
    securityText.textContent = isCurrentNetwork ? 'Connected' : this.getSecurityDisplayText(network.authmode);

    networkSecurity.appendChild(securityIcon);
    networkSecurity.appendChild(securityText);

    networkInfo.appendChild(networkName);
    networkInfo.appendChild(networkSecurity);

    const rightSide = document.createElement('div');
    rightSide.className = 'network-right';

    // Signal strength
    const signalContainer = document.createElement('div');
    signalContainer.className = 'signal-strength';
    this.createSignalBars(signalContainer, network.rssi);
    rightSide.appendChild(signalContainer);

    if (isCurrentNetwork) {
      // Connected checkmark (SVG namespace + class attribute)
      const checkIcon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      checkIcon.setAttribute('width', '14');
      checkIcon.setAttribute('height', '14');
      checkIcon.setAttribute('viewBox', '0 0 16 16');
      checkIcon.setAttribute('fill', 'none');
      checkIcon.setAttribute('class', 'connected-check');

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M13 4L6 11L3 8');
      path.setAttribute('stroke', 'currentColor');
      path.setAttribute('stroke-width', '2');
      path.setAttribute('stroke-linecap', 'round');
      path.setAttribute('stroke-linejoin', 'round');

      checkIcon.appendChild(path);
      // Put check left of bars so bars align right consistently
      rightSide.prepend(checkIcon);
    }

    networkItem.appendChild(networkInfo);
    networkItem.appendChild(rightSide);

    return networkItem;
  }

  // Create Security Icon
  createSecurityIcon(authmode) {
    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('class', 'security-icon');
    icon.setAttribute('width', '12');
    icon.setAttribute('height', '12');
    icon.setAttribute('viewBox', '0 0 12 12');
    icon.setAttribute('fill', 'none');

    if (authmode === 'OPEN') {
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M8.5 4.5V3C8.5 1.895 7.605 1 6.5 1H5.5C4.395 1 3.5 1.895 3.5 3V4.5M2.5 4.5H9.5C10.05 4.5 10.5 4.95 10.5 5.5V9.5C10.5 10.05 10.05 10.5 9.5 10.5H2.5C1.95 10.5 1.5 10.05 1.5 9.5V5.5C1.5 4.95 1.95 4.5 2.5 4.5Z');
      path.setAttribute('stroke', 'currentColor');
      path.setAttribute('stroke-width', '1');
      icon.appendChild(path);
    } else {
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', '2'); rect.setAttribute('y', '5');
      rect.setAttribute('width', '8'); rect.setAttribute('height', '6');
      rect.setAttribute('rx', '1');
      rect.setAttribute('stroke', 'currentColor'); rect.setAttribute('stroke-width', '1');

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M4 5V3.5C4 2.672 4.672 2 5.5 2H6.5C7.328 2 8 2.672 8 3.5V5');
      path.setAttribute('stroke', 'currentColor'); path.setAttribute('stroke-width', '1'); path.setAttribute('stroke-linecap', 'round');

      icon.appendChild(rect);
      icon.appendChild(path);
    }

    return icon;
  }

  // Get Security Display Text
  getSecurityDisplayText(authmode) {
    const securityMap = {
      'OPEN': 'Open', 'WEP': 'WEP',
      'WPA-PSK': 'WPA', 'WPA2-PSK': 'WPA2', 'WPA/WPA2-PSK': 'WPA/WPA2',
      'WPA2-ENT': 'WPA2 Enterprise', 'WPA3-PSK': 'WPA3', 'WPA2/WPA3-PSK': 'WPA2/WPA3',
      'WAPI-PSK': 'WAPI', 'OWE': 'OWE', 'SECURED': 'Secured'
    };
    return securityMap[authmode] || authmode;
  }

  // Create Signal Bars
  createSignalBars(container, rssi) {
    container.innerHTML = '';

    // Convert RSSI to signal quality
    let quality;
    if (rssi >= -50) quality = 'excellent';
    else if (rssi >= -60) quality = 'good';
    else if (rssi >= -75) quality = 'fair';
    else quality = 'poor';

    container.className = `signal-strength ${quality}`;

    for (let i = 0; i < 4; i++) {
      const bar = document.createElement('div');
      bar.className = 'signal-bar';
      container.appendChild(bar);
    }
  }

  // WiFi Modal Management
  openWifiModal(network) {
    const modal = document.getElementById('wifiModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalNetworkName = document.getElementById('modalNetworkName');
    const modalSecurityType = document.getElementById('modalSecurityType');
    const modalSignalStrength = document.getElementById('modalSignalStrength');
    const passwordGroup = document.getElementById('passwordGroup');
    const wifiPassword = document.getElementById('wifiPassword');

    modalTitle.textContent = `Connect to ${network.ssid}`;
    modalNetworkName.textContent = network.ssid;
    modalSecurityType.textContent = this.getSecurityDisplayText(network.authmode);

    this.createSignalBars(modalSignalStrength, network.rssi);

    // Show/hide password field based on security
    if (network.authmode === 'OPEN') {
      passwordGroup.style.display = 'none';
    } else {
      passwordGroup.style.display = 'block';
      wifiPassword.value = '';
      wifiPassword.focus();
    }

    modal.style.display = 'flex';
    modal.dataset.networkSsid = network.ssid;
    modal.dataset.networkAuthmode = network.authmode;
  }

  closeWifiModal() {
    const modal = document.getElementById('wifiModal');
    modal.style.display = 'none';

    // Reset form
    const wifiPassword = document.getElementById('wifiPassword');
    wifiPassword.value = '';
    wifiPassword.type = 'password';

    const toggleBtn = document.querySelector('#passwordGroup .toggle-password');
    const eyeOpen = toggleBtn.querySelector('.eye-open');
    const eyeClosed = toggleBtn.querySelector('.eye-closed');
    eyeOpen.style.display = 'block';
    eyeClosed.style.display = 'none';
  }

  // Handle WiFi Connection
  async handleWifiConnect(e) {
    e.preventDefault();

    const modal = document.getElementById('wifiModal');
    const ssid = modal.dataset.networkSsid;
    const authmode = modal.dataset.networkAuthmode;
    const password = document.getElementById('wifiPassword').value;

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnSpinner = submitBtn.querySelector('.btn-spinner');

    // Show loading state
    submitBtn.disabled = true;
    btnText.style.display = 'none';
    btnSpinner.style.display = 'flex';

    try {
      const config = { wifi_ssid: ssid, wifi_password: authmode === 'OPEN' ? '' : password };

      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });

      if (response.ok) {
        this.closeWifiModal();

        // Simulate connection process
        setTimeout(() => {
          this.currentConfig.wifi_ssid = ssid;
          this.renderNetworks();
          this.showToast(`Connected to ${ssid}`, 'success');
        }, 1200);
      } else {
        throw new Error('Failed to save WiFi configuration');
      }
    } catch (error) {
      console.error('WiFi connection failed:', error);
      this.showToast('WiFi connection failed', 'error');
    } finally {
      submitBtn.disabled = false;
      btnText.style.display = 'block';
      btnSpinner.style.display = 'none';
    }
  }

  // Handle Configuration Form Submit
  async handleConfigSubmit(e) {
    e.preventDefault();

    const formData = new FormData(e.target);
    const config = {};

    // Only include non-empty values
    for (const [key, value] of formData.entries()) {
      if (value && value.trim()) config[key] = value.trim();
    }

    const submitBtn = document.getElementById('saveBtn');
    const saveText = submitBtn.querySelector('.save-text');
    const saveSpinner = submitBtn.querySelector('.save-spinner');

    // Show loading state (keeps loader while saving)
    submitBtn.disabled = true;
    submitBtn.classList.add('saving');
    saveText.style.display = 'none';
    saveSpinner.style.display = 'flex';

    try {
      const response = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });

      if (response.ok) {
        // Success: stop loader, reset button, show toast (no button color change)
        submitBtn.classList.remove('saving');
        saveSpinner.style.display = 'none';
        saveText.textContent = 'Save';
        saveText.style.display = 'block';
        submitBtn.disabled = false;

        Object.assign(this.currentConfig, config);
        this.showToast('Configuration saved', 'success');
      } else {
        throw new Error('Failed to save configuration');
      }
    } catch (error) {
      console.error('Configuration save failed:', error);
      this.showToast('Configuration save failed', 'error');

      // Reset to normal state on error
      submitBtn.classList.remove('saving');
      saveSpinner.style.display = 'none';
      saveText.style.display = 'block';
      submitBtn.disabled = false;
    }
  }

  // Toast helper
  showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.setAttribute('role', 'status');
    toast.textContent = message;
    container.appendChild(toast);

    // Auto-remove after 3 seconds
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 3000);

    // Allow click to dismiss early
    toast.addEventListener('click', () => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    });
  }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new SmartBinConfig();
});

// Expose class for debugging
window.SmartBinConfig = SmartBinConfig;
